package com.cognizant.orm_learn;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException; // Import the exception

@SpringBootApplication // Marks this as a Spring Boot application [cite: 78]
public class OrmLearnApplication {

	// Logger for console output [cite: 65-67]
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	// Static reference to CountryService [cite: 134, 135]
	private static CountryService countryService;

	public static void main(String[] args) {
		LOGGER.info("Inside main"); // [cite: 70]
		// Get the Spring application context [cite: 143, 144]
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		// Get the CountryService bean from the context [cite: 145]
		countryService = context.getBean(CountryService.class);

		// --- Test Methods ---
		testGetAllCountries(); // Call the test method [cite: 146]

		try {
			testFindCountryByCode(); // Test finding a country [cite: 508]
		} catch (CountryNotFoundException e) {
			LOGGER.error("Error finding country: {}", e.getMessage());
		}

		testAddCountry(); // Test adding a country [cite: 517]
		testUpdateCountry(); // Test updating a country [cite: 529]
		testDeleteCountry(); // Test deleting a country [cite: 535]
	}

	private static void testGetAllCountries() {
		LOGGER.info("Start testGetAllCountries"); // [cite: 138]
		List<Country> countries = countryService.getAllCountries(); // [cite: 139]
		LOGGER.debug("Countries={}", countries); // [cite: 140]
		LOGGER.info("End testGetAllCountries"); // [cite: 141]
	}

	private static void testFindCountryByCode() throws CountryNotFoundException {
		LOGGER.info("Start testFindCountryByCode"); // [cite: 503]
		Country country = countryService.findCountryByCode("IN"); // Find India [cite: 504]
		LOGGER.debug("Country:{}", country); // [cite: 505]
		LOGGER.info("End testFindCountryByCode"); // [cite: 506]
	}

	private static void testAddCountry() {
		LOGGER.info("Start testAddCountry"); // [cite: 517]
		Country newCountry = new Country();
		newCountry.setCode("XY"); // Create new country instance [cite: 518]
		newCountry.setName("Xanadu");
		countryService.addCountry(newCountry); // Call service to add [cite: 519]
		LOGGER.debug("Added Country: {}", newCountry);
		try {
			Country addedCountry = countryService.findCountryByCode("XY"); // Verify addition [cite: 520]
			LOGGER.debug("Verified Added Country: {}", addedCountry);
		} catch (CountryNotFoundException e) {
			LOGGER.error("Failed to verify added country: {}", e.getMessage());
		}
		LOGGER.info("End testAddCountry");
	}

	private static void testUpdateCountry() {
		LOGGER.info("Start testUpdateCountry"); // [cite: 529]
		try {
			countryService.updateCountry("XY", "New Xanadu Name"); // Update country [cite: 529]
			Country updatedCountry = countryService.findCountryByCode("XY"); // Verify update
			LOGGER.debug("Updated Country: {}", updatedCountry);
		} catch (CountryNotFoundException e) {
			LOGGER.error("Failed to update country: {}", e.getMessage());
		}
		LOGGER.info("End testUpdateCountry");
	}

	private static void testDeleteCountry() {
		LOGGER.info("Start testDeleteCountry"); // [cite: 535]
		countryService.deleteCountry("XY"); // Delete the country [cite: 536]
		LOGGER.debug("Country 'XY' deleted.");
		try {
			countryService.findCountryByCode("XY"); // This should now throw an exception
		} catch (CountryNotFoundException e) {
			LOGGER.debug("Country 'XY' successfully deleted. Exception: {}", e.getMessage()); // Expected behavior
		}
		LOGGER.info("End testDeleteCountry");
	}
}