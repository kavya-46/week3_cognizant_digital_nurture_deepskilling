package com.cognizant.orm_learn;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException;

@SpringBootApplication
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService countryService;

	public static void main(String[] args) {
		LOGGER.info("Inside main");
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		countryService = context.getBean(CountryService.class);

		// --- Call Test Methods ---
		testGetAllCountries();
		try {
			testFindCountryByCode();
		} catch (CountryNotFoundException e) {
			LOGGER.error("Error finding country: {}", e.getMessage());
		}
		testAddCountry();
		testUpdateCountry();
		testDeleteCountry();
	}

	private static void testGetAllCountries() {
		LOGGER.info("Start testGetAllCountries");
		List<Country> countries = countryService.getAllCountries();
		LOGGER.debug("Countries={}", countries);
		LOGGER.info("End testGetAllCountries");
	}

	private static void testFindCountryByCode() throws CountryNotFoundException {
		LOGGER.info("Start testFindCountryByCode");
		Country country = countryService.findCountryByCode("IN");
		LOGGER.debug("Country:{}", country);
		LOGGER.info("End testFindCountryByCode");
	}

	private static void testAddCountry() {
		LOGGER.info("Start testAddCountry");
		Country newCountry = new Country();
		newCountry.setCode("XY");
		newCountry.setName("Xanadu");
		countryService.addCountry(newCountry);
		LOGGER.debug("Added Country: {}", newCountry);
		try {
			Country addedCountry = countryService.findCountryByCode("XY");
			LOGGER.debug("Verified Added Country: {}", addedCountry);
		} catch (CountryNotFoundException e) {
			LOGGER.error("Failed to verify added country: {}", e.getMessage());
		}
		LOGGER.info("End testAddCountry");
	}

	private static void testUpdateCountry() {
		LOGGER.info("Start testUpdateCountry");
		try {
			countryService.updateCountry("XY", "New Xanadu Name");
			Country updatedCountry = countryService.findCountryByCode("XY");
			LOGGER.debug("Updated Country: {}", updatedCountry);
		} catch (CountryNotFoundException e) {
			LOGGER.error("Failed to update country: {}", e.getMessage());
		}
		LOGGER.info("End testUpdateCountry");
	}

	private static void testDeleteCountry() {
		LOGGER.info("Start testDeleteCountry");
		countryService.deleteCountry("XY");
		try {
			countryService.findCountryByCode("XY");
		} catch (CountryNotFoundException e) {
			LOGGER.debug("Country 'XY' successfully deleted. Exception: {}", e.getMessage());
		}
		LOGGER.info("End testDeleteCountry");
	}
}