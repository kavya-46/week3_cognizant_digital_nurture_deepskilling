package com.cognizant.orm_learn.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.ormlearn.model.Country;

@Repository // Marks this as a Spring Data repository [cite: 118]
public interface CountryRepository extends JpaRepository<Country, String> {
    // JpaRepository provides methods like findAll(), findById(), save(), deleteById() automatically.
}