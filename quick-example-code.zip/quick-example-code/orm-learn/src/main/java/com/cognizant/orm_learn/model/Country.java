package com.cognizant.orm_learn.model

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="country") // Maps to 'country' table in DB [cite: 99, 100]
public class Country {
    @Id // Marks 'code' as the primary key [cite: 102]
    @Column(name="co_code") // Maps to 'co_code' column [cite: 103]
    private String code;

    @Column(name="co_name") // Maps to 'co_name' column [cite: 105]
    private String name;

    // --- Getters and Setters (You can generate these in IntelliJ) ---
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Country [code=" + code + ", name=" + name + "]";
    }
}