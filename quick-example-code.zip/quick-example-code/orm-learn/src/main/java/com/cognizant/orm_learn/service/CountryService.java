package com.cognizant.orm_learn.service;

import java.util.List;
import java.util.Optional; // Import Optional

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Import Transactional

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException; // Import your exception

@Service // Marks this as a Spring service component [cite: 128]
public class CountryService {

    @Autowired // Automatically injects CountryRepository [cite: 129]
    private CountryRepository countryRepository;

    @Transactional // Ensures methods run within a transaction [cite: 131]
    public List<Country> getAllCountries() {
        return countryRepository.findAll(); // Fetches all countries [cite: 132]
    }

    @Transactional
    public Country findCountryByCode(String countryCode) throws CountryNotFoundException { // [cite: 490, 494]
        Optional<Country> result = countryRepository.findById(countryCode); // [cite: 495, 496]
        if (!result.isPresent()) { // [cite: 497, 498]
            throw new CountryNotFoundException("Country not found with code: " + countryCode);
        }
        return result.get(); // [cite: 499, 500]
    }

    @Transactional
    public void addCountry(Country country) { // [cite: 512, 514]
        countryRepository.save(country); // Saves (adds) a new country [cite: 515, 516]
    }

    @Transactional
    public void updateCountry(String code, String newName) throws CountryNotFoundException { // [cite: 524]
        Country country = findCountryByCode(code); // Get the existing country [cite: 526]
        country.setName(newName); // Update its name [cite: 527]
        countryRepository.save(country); // Save (update) the country [cite: 528]
    }

    @Transactional
    public void deleteCountry(String countryCode) { // [cite: 533]
        countryRepository.deleteById(countryCode); // Deletes by ID [cite: 534]
    }
}