-- src/main/resources/data.sql
DELETE FROM country; -- Optional: to ensure a clean slate on each run

-- Insert a few countries to start with
INSERT INTO country (co_code, co_name) VALUES ('IN', 'India');
INSERT INTO country (co_code, co_name) VALUES ('US', 'United States of America');
INSERT INTO country (co_code, co_name) VALUES ('DE', 'Germany');
INSERT INTO country (co_code, co_name) VALUES ('AU', 'Australia');
-- Add more countries from the document's list if you wish